THYNK DIGITAL AGENCY · PRESS KIT (2026)
thynkagency.gr · Press contact: hello@thynkagency.gr

FILES (PNG and SVG)
- thynk-logo-light-bg                  the logo for light backgrounds: dark letters, lake-blue dot, transparent
- thynk-logo-dark-bg                   the logo for dark backgrounds: white letters, light-blue dot, transparent
- thynk-logo-digital-agency-light-bg   with "Digital Agency", for light backgrounds, transparent
- thynk-logo-digital-agency-dark-bg    with "Digital Agency", for dark backgrounds, transparent
- thynk-logo-on-white.png              on a white square, 2000 x 2000 px
- thynk-logo-on-lake.png               on a lake-blue square, 2000 x 2000 px
- thynk-icon                           the icon: the orange square dot on a lake-blue tile, 1024 x 1024 px

NAME
Thynk, with a y. Full name: Thynk Digital Agency.

USING THE LOGO
Please use the files as they are: no recolouring, stretching, outlines or effects.
Use the light-background version on light backgrounds and the dark-background version on dark ones.
Leave clear space around the logo at least as large as the height of its dot.

COLOURS
Lake #1D5866 · Sky #D3E7EE · Orange #FF6A1A · Ink #14262E · White #FFFFFF
Typeface: Commissioner (Google Fonts, SIL Open Font License).

ABOUT THYNK
Thynk Digital Agency is a marketing and digital transformation agency based in Ioannina, Greece. It was founded in 2026 by Dimitris Chrysochoou and Michael Boumpas and works with businesses across Greece and abroad. Its services cover digital marketing (advertising, social media, content and email) and digital transformation with AI (automation, data and reporting), along with consulting and web design. Every collaboration starts with an audit that shows where a business stands today and which steps will make the biggest difference first. thynkagency.gr

------------------------------------------------------------

THYNK DIGITAL AGENCY · ΥΛΙΚΟ ΓΙΑ ΤΟΝ ΤΥΠΟ (2026)
thynkagency.gr · Επικοινωνία για τον Τύπο: hello@thynkagency.gr

ΑΡΧΕΙΑ (PNG και SVG)
- thynk-logo-light-bg                  για ανοιχτά φόντα: σκούρα γράμματα, μπλε τελεία, διάφανο
- thynk-logo-dark-bg                   για σκούρα φόντα: λευκά γράμματα, γαλάζια τελεία, διάφανο
- thynk-logo-digital-agency-light-bg   με «Digital Agency», για ανοιχτά φόντα, διάφανο
- thynk-logo-digital-agency-dark-bg    με «Digital Agency», για σκούρα φόντα, διάφανο
- thynk-logo-on-white.png              σε λευκό τετράγωνο, 2000 x 2000 px
- thynk-logo-on-lake.png               σε μπλε τετράγωνο, 2000 x 2000 px
- thynk-icon                           το εικονίδιο: η πορτοκαλί τετράγωνη τελεία σε μπλε πλακίδιο, 1024 x 1024 px

ΤΟ ΟΝΟΜΑ
Thynk, με y. Πλήρης επωνυμία: Thynk Digital Agency.

ΤΟ ΛΟΓΟΤΥΠΟ
Χρησιμοποιήστε τα αρχεία όπως είναι: χωρίς αλλαγή χρώματος, παραμόρφωση, περιγράμματα ή εφέ.
Την εκδοχή για ανοιχτά φόντα σε ανοιχτό φόντο, την εκδοχή για σκούρα φόντα σε σκούρο.
Αφήστε γύρω από το λογότυπο κενό τουλάχιστον όσο το ύψος της τελείας του.

ΧΡΩΜΑΤΑ
Λίμνη #1D5866 · Ουρανός #D3E7EE · Πορτοκαλί #FF6A1A · Μελάνι #14262E · Λευκό #FFFFFF
Γραμματοσειρά: Commissioner (Google Fonts, SIL Open Font License).

ΣΧΕΤΙΚΑ ΜΕ ΤΗ THYNK
Η Thynk Digital Agency είναι εταιρεία marketing και ψηφιακού μετασχηματισμού με έδρα τα Ιωάννινα. Ιδρύθηκε το 2026 από τον Δημήτρη Χρυσοχόου και τον Μιχαήλ Μπούμπα και συνεργάζεται με επιχειρήσεις σε όλη την Ελλάδα και στο εξωτερικό. Οι υπηρεσίες της καλύπτουν το digital marketing (διαφήμιση, social media, περιεχόμενο και email) και τον ψηφιακό μετασχηματισμό με AI (αυτοματισμοί, δεδομένα και αναφορές), καθώς και συμβουλευτική και κατασκευή ιστοσελίδων. Κάθε συνεργασία ξεκινά με ένα audit, που δείχνει πού βρίσκεται σήμερα η επιχείρηση και ποια βήματα θα κάνουν πρώτα τη μεγαλύτερη διαφορά. thynkagency.gr
