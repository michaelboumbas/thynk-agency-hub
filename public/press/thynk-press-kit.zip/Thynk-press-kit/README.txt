THYNK DIGITAL AGENCY · PRESS KIT
thynkagency.gr · Press contact: hello@thynkagency.gr

FILES
- thynk-logo-dark-transparent.png    wordmark, dark, transparent background (for light backgrounds)
- thynk-logo-white-transparent.png   wordmark, white, transparent background (for dark backgrounds)
- thynk-logo-dark-on-white.png       wordmark on a white square, 2000 x 2000 px
- thynk-logo-white-on-dark.png       wordmark on a dark square, 2000 x 2000 px
- thynk-icon.png                     the icon: the orange square dot on a black tile, 1024 x 1024 px

NAME
Thynk, with a y. Full name: Thynk Digital Agency.

USING THE LOGO
Please use the files as they are: no recolouring, stretching, outlines or effects.
Use the dark version on light backgrounds and the white version on dark ones.

ABOUT THYNK
Thynk Digital Agency is a marketing and digital transformation agency based in Ioannina, Greece. It was founded in 2026 by Dimitris Chrysochoou and Michael Boumpas and works with businesses across Greece and abroad. Its services cover digital marketing (advertising, social media, content and email) and digital transformation with AI (automation, data and reporting), along with consulting and web design. Every collaboration starts with an audit that shows where a business stands today and which steps will make the biggest difference first. thynkagency.gr

------------------------------------------------------------

THYNK DIGITAL AGENCY · ΥΛΙΚΟ ΓΙΑ ΤΟΝ ΤΥΠΟ
thynkagency.gr · Επικοινωνία για τον Τύπο: hello@thynkagency.gr

ΤΟ ΟΝΟΜΑ
Thynk, με y. Πλήρης επωνυμία: Thynk Digital Agency.

ΤΟ ΛΟΓΟΤΥΠΟ
Χρησιμοποιήστε τα αρχεία όπως είναι: χωρίς αλλαγή χρώματος, παραμόρφωση, περιγράμματα ή εφέ.
Το σκούρο λογότυπο σε ανοιχτό φόντο, το λευκό σε σκούρο.

ΣΧΕΤΙΚΑ ΜΕ ΤΗ THYNK
Η Thynk Digital Agency είναι εταιρεία marketing και ψηφιακού μετασχηματισμού με έδρα τα Ιωάννινα. Ιδρύθηκε το 2026 από τον Δημήτρη Χρυσοχόου και τον Μιχαήλ Μπούμπα και συνεργάζεται με επιχειρήσεις σε όλη την Ελλάδα και στο εξωτερικό. Οι υπηρεσίες της καλύπτουν το digital marketing (διαφήμιση, social media, περιεχόμενο και email) και τον ψηφιακό μετασχηματισμό με AI (αυτοματισμοί, δεδομένα και αναφορές), καθώς και συμβουλευτική και κατασκευή ιστοσελίδων. Κάθε συνεργασία ξεκινά με ένα audit, που δείχνει πού βρίσκεται σήμερα η επιχείρηση και ποια βήματα θα κάνουν πρώτα τη μεγαλύτερη διαφορά. thynkagency.gr
